Brochure template for Travel Knowledge
======================================

1. Extract this folder to your computer.
2. Drop your PDF brochures into the matching sub-brand folder:
   - tmc/       The Modern Classroom School trips
   - rfu/       Umrah / religious trips
   - travelstall/ Travel Stall trips
   - visasure/  Visa Sure trips

3. Upload the entire 'brochure' folder to Google Drive.
4. In CRM → Travel Knowledge, select this folder as the brochure root and sync.

Note: Kindly do not change the root folder or subfolder names.
