Travel Knowledge brochure template
==================================

This template is for the Travel CRM's TMC (The Modern Classroom) brochures.

Quick setup
-----------
1. Extract this folder on your computer.
2. Put your TMC brochure PDFs inside the 'tmc' folder.
3. Upload the complete 'brochure' folder to Google Drive.
4. In the CRM, open Travel > Travel Knowledge and connect Google Drive.
5. Choose the uploaded 'brochure' folder and save it as the brochure folder.
6. Click 'Update library' to index the PDFs for search and recommendations.

How the folders are used
-------------------------
- Diagnostics uses the indexed TMC brochures when preparing travel recommendations.
- TMC Catalogue displays the PDFs from this same Drive connection and folder.
- PDFs generated from approved itineraries are placed in 'TMC/CRM Itineraries'.
- New or uploaded PDFs appear as 'Waiting for sync' until 'Update library' is run.

Important
---------
- Keep the folder names 'brochure' and 'tmc' unchanged.
- Add PDF files only; other file types are ignored.
- Keep the 'TMC/CRM Itineraries' folder inside 'tmc' so the catalogue can manage those files.
- Updating the library makes new brochures available to Diagnostics. It does not delete files.
